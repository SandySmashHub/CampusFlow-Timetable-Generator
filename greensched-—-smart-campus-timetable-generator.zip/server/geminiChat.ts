import { GoogleGenAI } from '@google/genai';
import { queryAll, getDb } from './db.js';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

const HINDI_DAY_KEYWORDS: Record<string, string> = {
  somwar: 'Monday',
  somvaar: 'Monday',
  monday: 'Monday',
  mangalwar: 'Tuesday',
  mangalvaar: 'Tuesday',
  tuesday: 'Tuesday',
  budhwar: 'Wednesday',
  budhvaar: 'Wednesday',
  wednesday: 'Wednesday',
  guruwar: 'Thursday',
  veervaar: 'Thursday',
  thursday: 'Thursday',
  shukrawar: 'Friday',
  shukravaar: 'Friday',
  jumma: 'Friday',
  friday: 'Friday',
  shaniwar: 'Saturday',
  shanivaar: 'Saturday',
  saturday: 'Saturday',
  ravivar: 'Sunday',
  sunday: 'Sunday',
};

export interface ChatResponse {
  answer: string;
  mode: string;
  model: string;
  matchedBatch?: string;
  calculatedTime?: string;
}

export function getFullScheduleContext() {
  return queryAll<any>(`
    SELECT 
      t.id as entry_id,
      s.name as subject_name,
      s.code as subject_code,
      b.name as batch_name,
      tea.name as teacher_name,
      tea.department as teacher_dept,
      c.name as classroom_name,
      c.capacity as classroom_cap,
      c.type as classroom_type,
      ts.day,
      ts.start_time,
      ts.end_time,
      ts.slot_index
    FROM timetable_entries t
    JOIN subjects s ON t.subject_id = s.id
    JOIN batches b ON t.batch_id = b.id
    JOIN teachers tea ON t.teacher_id = tea.id
    JOIN classrooms c ON t.classroom_id = c.id
    JOIN timeslots ts ON t.timeslot_id = ts.id
    ORDER BY ts.slot_index ASC
  `);
}

export async function processChatbotQuery(
  query: string,
  userBatchName: string = 'CS-A (3rd Year)'
): Promise<ChatResponse> {
  await getDb();
  const schedule = getFullScheduleContext();
  const lowerQuery = (query || '').toLowerCase().trim();

  // Current calendar day & time calculation
  const now = new Date();
  const dayIdx = now.getDay(); // 0 is Sun, 1 is Mon...
  const currentDay = dayIdx === 0 ? 'Sunday' : DAYS[dayIdx - 1];
  const currentTimeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

  // If timetable has not been generated yet
  if (schedule.length === 0) {
    return {
      answer: "Timetable abhi generate nahi hua hai. Kripya pehle Admin panel se 'Generate Clash-Free Schedule' par click karein.\n\n(No timetable entries found in the database. Please generate the timetable from the dashboard first.)",
      mode: 'Live Relational DB (Empty Schedule)',
      model: 'Relational SQLite',
    };
  }

  // Attempt server-side Gemini 3.8 Flash if GEMINI_API_KEY is available
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey && apiKey !== 'MY_GEMINI_API_KEY' && apiKey.trim().length > 5) {
    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const systemInstruction = `You are GreenSched's intelligent campus timetable assistant for a modern engineering college.
The user speaks English, Hindi, or Hinglish (e.g., "Mera Monday ka timetable kya hai?", "Mera next lecture kab hai?", "Which room is my next class in?", "Who teaches Database Management Systems?").
Current server day is: ${currentDay}.
Current server time is: ${currentTimeStr}.
The student is inquiring about batch: "${userBatchName}".

RULES:
1. Ground your answers 100% strictly in the verified timetable records provided below.
2. If the user asks in Hindi or Hinglish, answer warmly in natural conversational Hinglish/Hindi with clear details (Subject, Time, Classroom, Faculty).
3. If the user asks in English, answer in clean English.
4. For "next lecture", look at current day (${currentDay}) and current time (${currentTimeStr}) for batch "${userBatchName}". If all classes today are over or none today, pick the upcoming Monday morning class or earliest class and clearly mention it.
5. Format with neat bullet points, bold text, and botanical emoji (🌿, 🌱, ⏰, 🏛️).
6. Never make up fake rooms or subjects not in the database.

CURRENT TIMETABLE DATABASE RECORDS:
${JSON.stringify(schedule, null, 2)}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: query,
        config: {
          systemInstruction,
          temperature: 0.2,
        },
      });

      const text = response.text;
      if (text && text.trim().length > 0) {
        return {
          answer: text.trim(),
          mode: 'Live Gemini 3.8 Flash (Server-Side AI)',
          model: 'gemini-3.8-flash',
          matchedBatch: userBatchName,
          calculatedTime: `${currentDay} ${currentTimeStr}`,
        };
      }
    } catch (err: any) {
      console.warn('Gemini API call failed, falling back to deterministic parser:', err.message);
    }
  }

  // Deterministic Multilingual Rule Engine Fallback (Clearly labeled, never pretends to be live AI)
  return fallbackDeterministicParser(lowerQuery, userBatchName, schedule, currentDay, currentTimeStr);
}

function fallbackDeterministicParser(
  lowerQuery: string,
  userBatchName: string,
  schedule: any[],
  currentDay: string,
  currentTimeStr: string
): ChatResponse {
  // 1. "Who teaches [Subject]?" or "[Subject] kaun padhata hai?"
  const teachesPatterns = ['who teaches', 'kaun padhata', 'kon padhata', 'teacher of', 'faculty for', 'instructor'];
  if (teachesPatterns.some(p => lowerQuery.includes(p))) {
    const subjects = queryAll<any>(`
      SELECT s.name, s.code, t.name as teacher_name, t.department
      FROM subjects s
      JOIN teachers t ON s.teacher_id = t.id
    `);

    for (const sub of subjects) {
      if (
        lowerQuery.includes(sub.name.toLowerCase()) ||
        lowerQuery.includes(sub.code.toLowerCase()) ||
        (sub.name.toLowerCase().includes('database') && lowerQuery.includes('dbms')) ||
        (sub.name.toLowerCase().includes('operating') && lowerQuery.includes('os')) ||
        (sub.name.toLowerCase().includes('networks') && lowerQuery.includes('cn')) ||
        (sub.name.toLowerCase().includes('data structures') && lowerQuery.includes('dsa'))
      ) {
        return {
          answer: `🌿 **${sub.name}** (${sub.code}) is taught by **${sub.teacher_name}** from the ${sub.department} department.`,
          mode: 'Deterministic Timetable Parser (Zero-API Fallback)',
          model: 'Rule-Based Context Matcher',
          matchedBatch: userBatchName,
        };
      }
    }

    // If no specific subject named, list available faculty & subjects
    const list = subjects.slice(0, 5).map(s => `• **${s.name}** (${s.code}): 👨🏫 ${s.teacher_name}`).join('\n');
    return {
      answer: `Here are the subject faculty members for your department:\n\n${list}`,
      mode: 'Deterministic Timetable Parser (Zero-API Fallback)',
      model: 'Rule-Based Context Matcher',
      matchedBatch: userBatchName,
    };
  }

  // 2. "Mera next lecture kab hai?" / "Which room is my next class in?"
  const nextPatterns = ['next lecture', 'next class', 'agla lecture', 'agla class', 'which room is my next', 'next period'];
  if (nextPatterns.some(p => lowerQuery.includes(p))) {
    // Filter lectures for user's batch on current day
    const batchSchedule = schedule.filter(s =>
      s.batch_name.toLowerCase().includes(userBatchName.toLowerCase().split(' ')[0])
    );

    // Filter lectures on current day
    let todayLectures = batchSchedule.filter(s => s.day.toLowerCase() === currentDay.toLowerCase());

    // If no lectures today or today is weekend, pick Monday
    let upcoming = todayLectures.find(s => s.start_time >= currentTimeStr);
    let note = '';

    if (!upcoming) {
      const mondayLectures = batchSchedule.filter(s => s.day === 'Monday');
      if (mondayLectures.length > 0) {
        upcoming = mondayLectures[0];
        note = `(Aaj ${currentDay} ko aur classes nahi hain, agla lecture agle working day ka hai.)\n`;
      } else if (batchSchedule.length > 0) {
        upcoming = batchSchedule[0];
      }
    }

    if (upcoming) {
      return {
        answer: `🌱 **Aapka Next Scheduled Lecture:**\n${note}` +
          `• 📖 **Subject:** ${upcoming.subject_name} (${upcoming.subject_code})\n` +
          `• ⏰ **Time:** ${upcoming.start_time} - ${upcoming.end_time} (${upcoming.day})\n` +
          `• 🏛️ **Classroom / Room:** **${upcoming.classroom_name}** (${upcoming.classroom_type})\n` +
          `• 👨🏫 **Faculty:** ${upcoming.teacher_name}\n` +
          `• 👥 **Batch:** ${upcoming.batch_name}`,
        mode: 'Deterministic Timetable Parser (Calculated from Real Clock)',
        model: 'Dynamic Chronological Evaluator',
        matchedBatch: userBatchName,
        calculatedTime: `${currentDay} ${currentTimeStr}`,
      };
    }
  }

  // 3. Day-specific schedule ("Mera Monday ka timetable kya hai?")
  let targetDay: string | null = null;
  for (const [kw, day] of Object.entries(HINDI_DAY_KEYWORDS)) {
    if (lowerQuery.includes(kw)) {
      targetDay = day;
      break;
    }
  }

  if (targetDay || lowerQuery.includes('timetable') || lowerQuery.includes('schedule') || lowerQuery.includes('classes')) {
    const dayToQuery = targetDay || currentDay;
    const dayClasses = schedule.filter(s =>
      s.day.toLowerCase() === dayToQuery.toLowerCase() &&
      s.batch_name.toLowerCase().includes(userBatchName.toLowerCase().split(' ')[0])
    );

    if (dayClasses.length === 0) {
      return {
        answer: `🌿 **${dayToQuery}** ko ${userBatchName} ke liye koi lecture scheduled nahi hai (Free Day).`,
        mode: 'Deterministic Timetable Parser (Zero-API Fallback)',
        model: 'Rule-Based Context Matcher',
        matchedBatch: userBatchName,
      };
    }

    const classList = dayClasses
      .map(
        c =>
          `• ⏰ **${c.start_time} - ${c.end_time}** | **${c.subject_name}** (${c.subject_code})\n  🏛️ Room: **${c.classroom_name}** | 👨🏫 Faculty: ${c.teacher_name}`
      )
      .join('\n\n');

    return {
      answer: `📅 **${dayToQuery} Timetable for ${userBatchName}:**\n\n${classList}`,
      mode: 'Deterministic Timetable Parser (Zero-API Fallback)',
      model: 'Rule-Based Context Matcher',
      matchedBatch: userBatchName,
    };
  }

  // 4. Default helpful guide
  return {
    answer:
      `Namaste! Main GreenSched campus timetable assistant hoon 🌿.\n\nAap mujhse kisi bhi bhasha (Hindi ya English) me pooch sakte hain:\n` +
      `• *"Mera Monday ka timetable kya hai?"*\n` +
      `• *"Mera next lecture kab hai?"*\n` +
      `• *"Which room is my next class in?"*\n` +
      `• *"Who teaches Database Management Systems?"*\n\n` +
      `*Active batch: ${userBatchName}*`,
    mode: 'Deterministic Timetable Parser (Zero-API Fallback)',
    model: 'Rule-Based Context Matcher',
    matchedBatch: userBatchName,
  };
}
